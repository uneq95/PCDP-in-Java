/**
 * Source code from the Java Concurrent Programming Coursera course.
 */
package edu.coursera.concurrent;
